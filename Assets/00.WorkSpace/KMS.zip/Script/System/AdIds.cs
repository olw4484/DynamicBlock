using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class AdIds
{
#if UNITY_ANDROID
    public const string Interstitial = "ca-app-pub-4554669209191050/7736831580";
    public const string Banner = "ca-app-pub-4554669209191050/1255183715";
    public const string Rewarded = "ca-app-pub-4554669209191050/4480112857";
#elif UNITY_IOS
    public const string Interstitial = "ca-app-pub-xxxx/ios_interstitial";
    public const string Banner       = "ca-app-pub-xxxx/ios_banner";
    public const string Rewarded     = "ca-app-pub-xxxx/ios_rewarded";
#endif
}