using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

// ================================
// Project : DynamicBlock
// Script  : ManagerGroup.cs
// Desc    : �Ŵ��� ���/�ʱ�ȭ/��ȸ + Tick/Teardown
// ================================
[DisallowMultipleComponent]
[AddComponentMenu("System/ManagerGroup")]
public class ManagerGroup : MonoBehaviour
{
    public static ManagerGroup Instance { get; private set; }

    private readonly List<IManager> _managers = new();
    private ITickable[] _tickables;
    private bool _initialized;

    public IReadOnlyList<IManager> Managers => _managers;
    public bool IsInitialized => _initialized;

    private void Awake()
    {
        // 1) �̱��� ���� (�ߺ� ���� ����)
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        // 2) ��Ʈ �°� �� DontDestroyOnLoad
        if (transform.parent != null)
            transform.SetParent(null, worldPositionStays: true);

        DontDestroyOnLoad(gameObject);
    }

    public void Register(IManager mgr)
    {
        _managers.Add(mgr);
    }

    public void Initialize()
    {
        if (_initialized) return;

        var ordered = _managers.OrderBy(m => m.Order).ToList();

        foreach (var m in ordered) m.PreInit();
        foreach (var m in ordered) m.Init();
        foreach (var m in ordered) m.PostInit();

        _tickables = ordered.OfType<ITickable>().ToArray();
        _initialized = true;
    }

    private void Update()
    {
        if (!_initialized || _tickables == null) return;
        float dt = Time.deltaTime;
        for (int i = 0; i < _tickables.Length; i++)
            _tickables[i].Tick(dt);
    }

    private void OnDestroy()
    {
        // �ߺ� �ı��� ������ ��� Teardown ����
        if (Instance != this) return;

        if (_initialized)
        {
            foreach (var td in _managers.AsEnumerable().Reverse().OfType<ITeardown>())
                td.Teardown();
        }
        Instance = null;
    }

    // ��ȸ (���׸�/���÷���)
    public T Resolve<T>() where T : class { return _managers.OfType<T>().FirstOrDefault(); }

    public IManager Resolve(System.Type t)
        => _managers.FirstOrDefault(m => t.IsInstanceOfType(m));

    public void SoftReset()
    {
        // �ʱ�ȭ �������
        for (int i = 0; i < _managers.Count; i++)
            if (_managers[i] is IRuntimeReset r) r.ResetRuntime();
    }
}
